<?php

/*
 * Theme setup
 * Image sizes registered here
 */
require 'inc/setup.php';

/*
 * ACF functions
 */
require 'inc/acf.php';

/*
 * Menus
 */
require 'inc/menus.php';

/*
 * Breadcrumb
 */
require 'inc/breadcrumb.php';

/*
 * Media
 */
require 'inc/media.php';

/*
 * Post Types
 */
require 'inc/posttypes.php';

/*
 * Pagination
 */
require 'inc/pagination.php';

add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title',3 );


//filter product
function filer_by_color(){
    //echo '<pre>';print_r($_POST);echo '</pre>';exit;

                    $order_by = ( ! empty( $_POST['orderby'] ) ) ? $_POST['orderby'] : '';
                    if ( 'price' === $order_by ) {
                        
                        $meta_key = '_price';
                        $orderby = 'meta_value_num';
                        $order = 'ASC';
                    }
                    if ( 'price-desc' === $order_by ) {
                        $meta_key = '_price';
                        $orderby = 'meta_value_num';
                        $order = 'DESC';
                    }
                    if ( 'rating' === $order_by ) {
                        $meta_key = '_wc_average_rating';
                        $orderby = 'meta_value_num';
                        $order = 'DESC';
                    }
                    if ( 'popularity' === $order_by ) {
                        $meta_key = '_wc_review_count';
                        $orderby = 'meta_value_num';
                        $order = 'DESC';
                    }
                    $default_posts_per_page = get_option( 'posts_per_page' );
                    $args= array(
                      'post_type'           => array('product'),
                      'post_status'         => 'publish',
                      'posts_per_page'        => $default_posts_per_page,
                      'tax_query'           => array(
                      ),
                      'orderby' => $orderby,
                      'meta_key' => $meta_key,
                        'order' => $order,
                        'suppress_filters' => true
                    );
                    
                    if(isset($_POST['frame_filter'])&&!empty($_POST['frame_filter'])){
                        $category_filter = array(
                          'taxonomy'        => 'pa_frame-size',
                          'field'           => 'slug',
                          'terms'           => $_POST['frame_filter'],
                          'operator'        => 'IN',
                        );
                        array_push($args['tax_query'],$category_filter);
                    }
                    
                    if(isset($_POST['filter_data'])&&!empty($_POST['filter_data'])){
                        $category_filter = array(
                          'taxonomy'        => 'pa_color',
                          'field'           => 'slug',
                          'terms'           => $_POST['filter_data'],
                          'operator'        => 'IN',
                        );
                        array_push($args['tax_query'],$category_filter);
                    }
                    
                    if(isset($_POST['brand_data'])&&!empty($_POST['brand_data'])){
                        $category_filter = array(
                          'taxonomy'        => 'pa_brand',
                          'field'           => 'slug',
                          'terms'           => $_POST['brand_data'],
                          'operator'        => 'IN',
                        );
                        array_push($args['tax_query'],$category_filter);
                    }
                    
                    
                    if(isset($_POST['material_data'])&&!empty($_POST['material_data'])){
                        $category_filter = array(
                          'taxonomy'        => 'pa_material',
                          'field'           => 'slug',
                          'terms'           => $_POST['material_data'],
                          'operator'        => 'IN',
                        );
                        array_push($args['tax_query'],$category_filter);
                    }

                    if(isset($_POST['shape_data'])&&!empty($_POST['shape_data'])){
                        $category_filter = array(
                          'taxonomy'        => 'pa_shape',
                          'field'           => 'slug',
                          'terms'           => $_POST['shape_data'],
                          'operator'        => 'IN',
                        );
                        array_push($args['tax_query'],$category_filter);
                    }

                    if(isset($_POST['style_data'])&&!empty($_POST['style_data'])){
                        $category_filter = array(
                          'taxonomy'        => 'pa_style',
                          'field'           => 'slug',
                          'terms'           => $_POST['style_data'],
                          'operator'        => 'IN',
                        );
                        array_push($args['tax_query'],$category_filter);
                    }
                    if(isset($_POST['type_data'])&&!empty($_POST['type_data'])){
                        $category_filter = array(
                          'taxonomy'        => 'pa_types',
                          'field'           => 'slug',
                          'terms'           => $_POST['type_data'],
                          'operator'        => 'IN',
                        );
                        array_push($args['tax_query'],$category_filter);
                    }

                    if(isset($_POST['activity_data'])&&!empty($_POST['activity_data'])){
                        $category_filter = array(
                          'taxonomy'        => 'pa_activity',
                          'field'           => 'slug',
                          'terms'           => $_POST['activity_data'],
                          'operator'        => 'IN',
                        );
                        array_push($args['tax_query'],$category_filter);
                    }
                    
                    if(isset($_POST['cat_filter'])&&!empty($_POST['cat_filter'])){
                        $category_filter = array(
                          'taxonomy'        => 'product_cat',
                          'field'           => 'slug',
                          'terms'           => $_POST['cat_filter'],
                          'operator'        => 'IN',
                        );
                        array_push($args['tax_query'],$category_filter);
                    }else{
                        if(isset($_POST['url_data' ]['product_cat'])){
                        $cat = $_POST['url_data' ]['product_cat'];
                        $category_filter = array(
                          'taxonomy'        => 'product_cat',
                          'field'           => 'slug',
                          'terms'           => array($cat),
                          'operator'        => 'IN',
                        );
                        array_push($args['tax_query'],$category_filter);
                    }
                    }
                    if(isset($_POST['url_data' ]['product_tag'])){
                        $tag = $_POST['url_data' ]['product_tag'];
                        $tag_filter = array(
                          'taxonomy'        => 'product_tag',
                          'field'           => 'slug',
                          'terms'           => array($tag),
                          'operator'        => 'IN',
                        );
                        array_push($args['tax_query'],$tag_filter);
                        }

                    if(isset($_POST['s'])){
                        $args['s'] = $_POST['s'];
                    }
                    
                    $loop = new WP_Query( $args );
                    
                    wp_reset_query(); 
                    if(count($loop->posts)==0){
                        ?><h2>No Product Found</h2><?php
                    }

                    ?>
                        
                    <?php
                       while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>

                    <li class="col-md-4">
                        <div class="product-card">
                            <div class="product-img mb-4">
                                    <?php echo do_shortcode('[yith_wcwl_add_to_wishlist]'); ?>
    								<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><img src="<?php echo wp_get_attachment_url( $product->get_image_id()); ?>" alt=""/></a>
                                    <div class="color-icon">
                                        <ul class="d-flex">
                                           <?php 

                                                                                $args = array(
                                            'post_type'     => 'product_variation',
                                            'post_status'   => array( 'private', 'publish' ),
                                            'numberposts'   => -1,
                                            'orderby'       => 'menu_order',
                                            'order'         => 'asc',
                                            'post_parent'   => get_the_ID() // get parent post-ID
                                        );
                                        $variations = get_posts( $args );

                                         foreach ( $variations as $variation ) {
                                            $variation_ID = $variation->ID;
                                            $variation = new WC_Product_Variation( $variation_ID );
                                           
                                           $image_tag = $variation->get_image();
                                           $image_id = $variation->get_image_id();
                                           $image_attributes = wp_get_attachment_image_src( $image_id );
                                          $image_url = $image_attributes[0];
                                           
                                            //echo $image_tag;
                                         $single_variation = $variation->get_data();
                                         $color_name = $single_variation['attributes']['pa_color'];
                                         ?>  <li image_url="<?php echo $image_url;    ?>" class="<?php  echo $color_name;  ?> variant_color"><a href="javascript:void(0)"><?php  echo $color_name;  ?></a></li> <?php

                                         }
                                         ?>
                                        </ul>
                                    </div>
    						</div>
                            <div class="cat-grid">
                                <div class="product-title my-2"><a href="<?php the_permalink(); ?>" id="id-<?php the_id(); ?>" title="<?php the_title(); ?>"><?php echo get_the_title(); ?></a></div>
                                <div class="price-quote">
                                    <p class="<?php echo esc_attr( apply_filters( 'woocommerce_product_price_class', 'price' ) ); ?>"><?php echo $product->get_price_html(); ?></p>
                                </div>
                            </div>
    					</div>
					</li>
					

                    			
                    <?php endwhile; ?>
                    <script type="text/javascript">
                        $('.variant_color').click(function(){
                            var image_url = $(this).attr('image_url');
                            $(this).parent().parent().parent().find('img').attr('src',image_url);
                        });
                    </script>
                <?php
                if(isset($_POST['ratings_filter'])){
                	if($rattingcount==0){
                		?><h2>No Product Found</h2><?php
                	}
                }
                ?>
                

                   
                    
                            <nav class="pagination-nav mt-4 mb-4">
                                <div class="pagenavi">
                                    
                                    <?php 
                                        $big = 999999999; // need an unlikely integer   
                                        $mybaseurl = get_site_url().'?';
                                        if(isset($_POST['url_data' ]['product_cat'])){
                                            $mybaseurl .= 'product_cat='.$_POST['url_data' ]['product_cat'];
                                        } 
                                        if(isset($_POST['url_data' ]['product_tag'])){
                                            $mybaseurl .= 'product_tag='.$_POST['url_data' ]['product_tag'];
                                        } 
                                        if(isset($_POST['orderby'])){
                                            $mybaseurl .= '&orderby='.$_POST['orderby'];
                                        } 
                                        if(isset($_POST['filter_data'])){
                                            $mybaseurl .= '&color='.implode(",",$_POST['filter_data']);
                                        }
                                        if(isset($_POST['frame_filter'])){
                                            $mybaseurl .= '&frame='.implode(",",$_POST['frame_filter']);
                                        }
                                        if(isset($_POST['brand_data'])){
                                            $mybaseurl .= '&brand='.implode(",",$_POST['brand_data']);
                                        }
                                        if(isset($_POST['material_data'])){
                                            $mybaseurl .= '&material='.implode(",",$_POST['material_data']);
                                        }
                                        if(isset($_POST['shape_data'])){
                                            $mybaseurl .= '&shape='.implode(",",$_POST['shape_data']);
                                        }
                                        if(isset($_POST['style_data'])){
                                            $mybaseurl .= '&style='.implode(",",$_POST['style_data']);
                                        }
                                        if(isset($_POST['type_data'])){
                                            $mybaseurl .= '&type='.implode(",",$_POST['type_data']);
                                        }
                                        if(isset($_POST['activity_data'])){
                                            $mybaseurl .= '&activity='.implode(",",$_POST['activity_data']);
                                        }
                                        if(isset($_POST['cat_filter'])){
                                            $mybaseurl .= '&cat='.implode(",",$_POST['cat_filter']);
                                        }  
                                        $pagination = paginate_links(array(
                                            'mid_size'  => 2,
                                            'prev_text' =>esc_html__('Previous', 'travel-tour'),
                                            'next_text' => esc_html__('Next', 'travel-tour'),
                                            'current' => max( 1, $_GET['pgs'] ),
                                            'total' => $loop->max_num_pages,
                                            'type' => 'array',
                                            'base'      => $mybaseurl.'%_%',
                                            'format'    => '&pgs=%#%',

                                        ) );
                                        echo '<li>' . implode( '</li><li>', $pagination ) . '</li>';
                                    ?>
                                    
                                </div> 
                            </nav>
                            


                    <?php


    wp_die(); 
}
add_action( 'wp_ajax_filer_by_color', 'filer_by_color' );
add_action('wp_ajax_nopriv_filer_by_color', 'filer_by_color');


// create hook for file uploading
add_action('wp_ajax_nopriv_upload_file', 'upload_file_callback');
add_action( 'wp_ajax_upload_file', 'upload_file_callback' );

function upload_file_callback(){
    // check security nonce which one we created in html form and sending with data.
    check_ajax_referer('uploadingFile', 'security');

    // removing white space
    $fileName = preg_replace('/\s+/', '-', $_FILES["file"]["name"]);

    // removing special character but keep . character because . seprate to extantion of file
    $fileName = preg_replace('/[^A-Za-z0-9.\-]/', '', $fileName);

    // rename file using time
    $fileName = time().'-'.$fileName;

    // upload file
    $$fileName = wp_upload_bits($fileName, null, file_get_contents($_FILES["file"]["tmp_name"]));
    if($fileName)
    {
    
        echo wp_get_upload_dir()['url'].'/'.$fileName;
        exit;
    }
    else{
        echo "No File Uploaded";
    }
}

/** Remove product data tabs */
 
add_filter( 'woocommerce_product_tabs', 'my_remove_product_tabs', 98 );
 
function my_remove_product_tabs( $tabs ) {
  unset( $tabs['additional_information'] ); // To remove the additional information tab
  return $tabs;
}
//remove download from my account
function custom_my_account_menu_items( $items ) {
    unset($items['downloads']);
    return $items;
}
add_filter( 'woocommerce_account_menu_items', 'custom_my_account_menu_items' );

//** Remove Sale Badge  */
add_filter('woocommerce_sale_flash', 'hide_sale_flash');
function hide_sale_flash()
{
return false;
}


// bootstrap 5 wp_nav_menu walker
class bootstrap_5_wp_nav_menu_walker extends Walker_Nav_menu
{
  private $current_item;
  private $dropdown_menu_alignment_values = [
    'dropdown-menu-start',
    'dropdown-menu-end',
    'dropdown-menu-sm-start',
    'dropdown-menu-sm-end',
    'dropdown-menu-md-start',
    'dropdown-menu-md-end',
    'dropdown-menu-lg-start',
    'dropdown-menu-lg-end',
    'dropdown-menu-xl-start',
    'dropdown-menu-xl-end',
    'dropdown-menu-xxl-start',
    'dropdown-menu-xxl-end'
  ];

  function start_lvl(&$output, $depth = 0, $args = null)
  {
    $dropdown_menu_class[] = '';
    foreach($this->current_item->classes as $class) {
      if(in_array($class, $this->dropdown_menu_alignment_values)) {
        $dropdown_menu_class[] = $class;
      }
    }
    $indent = str_repeat("\t", $depth);
    $submenu = ($depth > 0) ? ' sub-menu' : '';
    $output .= "\n$indent<ul class=\"dropdown-menu$submenu " . esc_attr(implode(" ",$dropdown_menu_class)) . " depth_$depth\">\n";
  }

  function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
  {
    $this->current_item = $item;

    $indent = ($depth) ? str_repeat("\t", $depth) : '';

    $li_attributes = '';
    $class_names = $value = '';

    $classes = empty($item->classes) ? array() : (array) $item->classes;

    $classes[] = ($args->walker->has_children) ? 'dropdown' : '';
    $classes[] = 'nav-item';
    $classes[] = 'nav-item-' . $item->ID;
    if ($depth && $args->walker->has_children) {
      $classes[] = 'dropdown-menu dropdown-menu-end';
    }

    $class_names =  join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
    $class_names = ' class="' . esc_attr($class_names) . '"';

    $id = apply_filters('nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args);
    $id = strlen($id) ? ' id="' . esc_attr($id) . '"' : '';

    $output .= $indent . '<li ' . $id . $value . $class_names . $li_attributes . '>';

    $attributes = !empty($item->attr_title) ? ' title="' . esc_attr($item->attr_title) . '"' : '';
    $attributes .= !empty($item->target) ? ' target="' . esc_attr($item->target) . '"' : '';
    $attributes .= !empty($item->xfn) ? ' rel="' . esc_attr($item->xfn) . '"' : '';
    $attributes .= !empty($item->url) ? ' href="' . esc_attr($item->url) . '"' : '';

    $active_class = ($item->current || $item->current_item_ancestor || in_array("current_page_parent", $item->classes, true) || in_array("current-post-ancestor", $item->classes, true)) ? 'active' : '';
    $nav_link_class = ( $depth > 0 ) ? 'dropdown-item ' : 'nav-link ';
    $attributes .= ( $args->walker->has_children ) ? ' class="'. $nav_link_class . $active_class . ' dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"' : ' class="'. $nav_link_class . $active_class . '"';

    $item_output = $args->before;
    $item_output .= '<a' . $attributes . '>';
    $item_output .= $args->link_before . apply_filters('the_title', $item->title, $item->ID) . $args->link_after;
    $item_output .= '</a>';
    $item_output .= $args->after;

    $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
  }
}
// register a new menu
register_nav_menu('primary-menu', 'Primary Menu');