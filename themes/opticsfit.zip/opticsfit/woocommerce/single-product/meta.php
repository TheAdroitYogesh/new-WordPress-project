<?php
/**
 * Single Product Meta
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/meta.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;
?><br/>

<div class="product_meta">

	<?php do_action( 'woocommerce_product_meta_start' ); ?> 
    
	<?php echo wc_get_product_tag_list( $product->get_id(), ', ', '<span class="tagged_as">' . _n( 'Tag:', 'Tags:', count( $product->get_tag_ids() ), 'woocommerce' ) . ' ', '</span>' ); ?>

	<?php do_action( 'woocommerce_product_meta_end' ); ?>

</div>

<div class="choose_lense_form" style="display: none;">
    <div>
     <p>Choose Lense Type</p>
     <div class="powered_spacs lense_type_sec" data="Single Vision Glasses">
        <div class="powered_spacs_img lense_type_img" >
            <i class="fas fa-binoculars"></i>
        </div>
        <div class="powered_spacs_data lense_type_data">
            <div class="powered_spacs_title lense_type_title">Single Vision Glasses</div>
            <div class="powered_spacs_description lense_type_description">
                <p>For Distance And Near Vision</p>
                <p>(Thin, anti-glare, blue-cut options)</p>
            </div>
        </div>
     </div>
     <div class="dual_vision_spacs lense_type_sec" data="Dual Vision Glasses">
        <div class="dual_vision_spacs_img lense_type_img" >
            <i class="fa-solid fa-glasses"></i>
        </div>
        <div class="dual_vision_spacs_data lense_type_data">
            <div class="dual_vision_spacs_title lense_type_title">Dual Vision Glasses</div>
            <div class="dual_vision_spacs_description lense_type_description">
                <p>Biforal & Progessives</p>
                <p>(For two powers in same lens)</p>
            </div>
        </div>
     </div>
     <div class="zero_power_blue_computer_glasses lense_type_sec" data="0 Power BLUE Computer Glasses">
        <div class="zero_power_blue_computer_glasses_img lense_type_img">
            <i class="fa-solid fa-glasses"></i>
        </div>
        <div class="zero_power_blue_computer_glasses_data lense_type_data">
            <div class="zero_power_blue_computer_glasses_title lense_type_title">0 Power BLUE Computer Glasses</div>
            <div class="zero_power_blue_computer_glasses_description lense_type_description">
                <p>Block 98% of harmful rays</p>
                <p>(Anti-glare and blue-cut options)</p>
            </div>
        </div>
     </div>
     <div class="frame_only lense_type_sec" data="Only Frame">
        <div class="frame_only_img lense_type_img" >
            <i class="fa-solid fa-glasses"></i>
        </div>
        <div class="frame_only_data lense_type_data">
            <div class="frame_only_title lense_type_title">Only Frame</div>
            <div class="frame_only_description lense_type_description">
                <p>Buy Only Frame</p>
            </div>
        </div>
     </div>


        
    </div>
</div>

<div class="upload_form_outer">
    <form id="formId" method="post" enctype="multipart/form-data" autocomplete="off">
        <p>Upload Prescription Or Enter Manualy</p>
        <div class="UploadImage">
            <input type="file" name="file" id="file" class="uploadfileinput" />
            <input name="security" value="<?php echo wp_create_nonce("uploadingFile"); ?>" type="hidden">
            <input name="action" value="upload_file" type="hidden"/>
            <input class="wcpa_pbutton uploadfilebutton" name="submit" value="upload" type="submit" />
        </div>
        <p class="uploaderror" style="color: red;"></p>
        <p class='inputnextbutton wcpa_pbutton'>Enter Manually</p>
        <p class='inputcancelbutton wcpa_pbutton'>Back</p>
    </form>
</div>
<script type="text/javascript">

             $('.showpopupforinput').click(function(){
                $('.choose_lense_form').show();
                $('.quantity').hide();
                $(".single_add_to_cart_button").hide();
            });
            $('.powered_spacs').click(function(){
                $('#hidden-1653471441399').val($(this).attr('data'));
                $('.single_vission_lenses_list').show();
                $('.dual_vission_lenses_list').hide();
                $('.upload_form_outer').show();
                $('.choose_lense_form').hide();
            });
            $('.dual_vision_spacs').click(function(){
                $('#hidden-1653471441399').val($(this).attr('data'));
                $('.single_vission_lenses_list').hide();
                $('.dual_vission_lenses_list').show();
                $('.upload_form_outer').show();
                $('.choose_lense_form').hide();
            });
            $('.zero_power_blue_computer_glasses').click(function(){
                $('#hidden-1653471441399').val($(this).attr('data'));
                $('#hidden-1653912001493').val('');
                $('.uploadfileinput').val('');
                $('.choose_lense_form').hide();
                $('.showpopupforinput').hide();
                $('.quantity').show();
                $(".single_add_to_cart_button").show();
                $(".add_to_cart_quantity").show();
            });
            $('.frame_only').click(function(){
                $('#hidden-1653471441399').val('');
                $('#hidden-1653912001493').val('');
                $('.uploadfileinput').val('');
                $('.choose_lense_form').hide();
                $('.showpopupforinput').hide();
                $('.quantity').show();
                $(".single_add_to_cart_button").show();
                $(".add_to_cart_quantity").show();
            });
            $('.inputcancelbutton').click(function(){
                $('.upload_form_outer').hide();
                $('.choose_lense_form').show();
            });


            $('.inputnextbutton').click(function(){  
                 $('.upload_form_outer').hide();
                 $('.wcpa_form_outer').show();
                 $('.wcpa_cancle').show();
                 $('.wcpa_next').show();
                 $('#hidden-1653912001493').val('-');
                 $('#hidden-1648722949356').val('-');
            });
            $('.wcpa_next').click(function(){
                flag = true;

                let singlepowercheck = $('#singlepower_0')[0].checked;
                let cylinderpowercheck = $('#cylindricalpower_0')[0].checked;

                if(singlepowercheck&&cylinderpowercheck){
                    var odsph = $('[name="select-1653912043407"]').val(); 
                    if(odsph==''){
                        $('.error_validation').html('*Please select OD SPH');
                        flag = false;
                        return false;
                    }
                    var odsph = $('[name="select-1653912082469"]').val(); 
                    if(odsph==''){
                        $('.error_validation').html('*Please select OD CYL');
                        flag = false;
                        return false;
                    }
                    var odsph = $('[name="select-1653912104378"]').val(); 
                    if(odsph==''){
                        $('.error_validation').html('*Please select OD Axis');
                        flag = false;
                        return false;
                    }
                    var odsph = $('[name="select-1653912867557"]').val(); 
                    if(odsph==''){
                        $('.error_validation').html('*Please select PD');
                        flag = false;
                        return false;
                    }

                }

                if(!singlepowercheck&&cylinderpowercheck){
                        var odsph = $('[name="select-1648469413360"]').val(); 
                        if(odsph==''){
                            $('.error_validation').html('*Please select OD SPH');
                            flag = false;
                            return false;
                        }

                        var odcyl = $('[name="select-1648720416566"]').val(); 
                        if(odcyl==''){
                            $('.error_validation').html('*Please select OD CYL');
                            flag = false;
                            return false;
                        }


                        var odaxis = $('[name="select-1648720474897"]').val(); 
                        if(odaxis==''){
                            $('.error_validation').html('*Please select OD Axis');
                            flag = false;
                            return false;
                        }
                        var odaxis = $('[name="select-1653992869378"]').val(); 
                        if(odaxis==''){
                            $('.error_validation').html('*Please select OD DP');
                            flag = false;
                            return false;
                        }

                        var ossph = $('[name="select-1649673595249"]').val(); 
                        if(ossph==''){
                            $('.error_validation').html('*Please select OS SPH');
                            flag = false;
                            return false;
                        }

                        var oscyl = $('[name="select-1649673650876"]').val(); 
                        if(oscyl==''){
                            $('.error_validation').html('*Please select OS CYL');
                            flag = false;
                            return false;
                        }


                        var osaxis = $('[name="select-1649673702476"]').val(); 
                        if(osaxis==''){
                            $('.error_validation').html('*Please select OS Axis');
                            flag = false;
                            return false;
                        }

                        var odaxis = $('[name="select-1653992811652"]').val(); 
                        if(odaxis==''){
                            $('.error_validation').html('*Please select OS DP');
                            flag = false;
                            return false;
                        }

                        var pdright = $('[name="select-1648721144048"]').val(); 
                        if(pdright==''){
                            $('.error_validation').html('*Please select PD Right');
                            flag = false;
                            return false;
                        }


                        var pdleft = $('[name="select-1648721220615"]').val(); 
                        if(pdleft==''){
                            $('.error_validation').html('*Please select PD Left');
                            flag = false;
                            return false;
                        }

                }

                if(singlepowercheck&&!cylinderpowercheck){
                    var odsph = $('[name="select-1653912043407"]').val(); 
                    if(odsph==''){
                        $('.error_validation').html('*Please select OD SPH');
                        flag = false;
                        return false;
                    }
                    var odsph = $('[name="select-1653912867557"]').val(); 
                    if(odsph==''){
                        $('.error_validation').html('*Please select PD');
                        flag = false;
                        return false;
                    }

                }

                

                if(!singlepowercheck&&!cylinderpowercheck){
                        var odsph = $('[name="select-1648469413360"]').val(); 
                        if(odsph==''){
                            $('.error_validation').html('*Please select OD SPH');
                            flag = false;
                            return false;
                        }
                        var odaxis = $('[name="select-1653992869378"]').val(); 
                        if(odaxis==''){
                            $('.error_validation').html('*Please select OD AP');
                            flag = false;
                            return false;
                        }

                        var ossph = $('[name="select-1649673595249"]').val(); 
                        if(ossph==''){
                            $('.error_validation').html('*Please select OS SPH');
                            flag = false;
                            return false;
                        }

                        var odaxis = $('[name="select-1653992811652"]').val(); 
                        if(odaxis==''){
                            $('.error_validation').html('*Please select OS AP');
                            flag = false;
                            return false;
                        }

                        var pdright = $('[name="select-1648721144048"]').val(); 
                        if(pdright==''){
                            $('.error_validation').html('*Please select PD Right');
                            flag = false;
                            return false;
                        }


                        var pdleft = $('[name="select-1648721220615"]').val(); 
                        if(pdleft==''){
                            $('.error_validation').html('*Please select PD Left');
                            flag = false;
                            return false;
                        }

                }



                if(flag){
                    $('.error_validation').html('');
                    $('.wcpa_selectlens_back').css('display','inline-block');
                    $('.wcpa_selectlens_next').css('display','inline-block');
                    $('.wcpa_cancle').hide();
                    $('.wcpa_next').hide();
                    $('.wcpa_form_outer select').prop('disabled', true);
                    $('#cylindricalpower_0').prop('disabled', true);
                    $('#singlepower_0').prop('disabled', true);

                    $('.wcpa_form_outer select').css('border', '0px');
                    $('.wcpa_form_outer select').css('background', '#f9f9f9');
                    $('.select_arrow').hide();
                    
                }
                 
            });

            $('.wcpa_selectlens_back').click(function(){
                 $('.wcpa_selectlens_back').hide();
                    $('.wcpa_selectlens_next').hide();
                    $('.wcpa_cancle').show();
                    $('.wcpa_next').show();
                    $('.wcpa_form_outer select').prop('disabled', false);
                    $('#cylindricalpower_0').prop('disabled', false);
                    $('#singlepower_0').prop('disabled', false);
                    $('.wcpa_form_outer select').css('border', '1px solid #aaa');
                    $('.wcpa_form_outer select').css('background', '#fff');
                    $('.select_arrow').show();
                    
            });
            $('.wcpa_selectlens_next').click(function(){
                $('.wcpa_form_outer select').prop('disabled', false);
                $('#cylindricalpower_0').prop('disabled', false);
                $('#singlepower_0').prop('disabled', false);
                $('.wcpa_form_outer').hide();
                $('.addonproductcancelbutton').attr('backclass','wcpa_form_outer');
                $('.wapf-wrapper').show();
                 
            });
            $('.wcpa_cancle').click(function(){
                 $('.wcpa_form_outer').hide();
                 $('.upload_form_outer').show();
            });
            $('.addonproductcancelbutton').click(function(){
                 $('.wapf-wrapper').hide();
                 $('.'+$('.addonproductcancelbutton').attr('backclass')).show();
            });
        
            
            $('.wapf-swatch').click(function(){
                 $('.wapf-wrapper').hide();
                 $('.showpopupforinput').hide();
                 $('.uploadfileinput').val('');
                 $('.quantity').show();
                $(".add_to_cart_quantity").show();
                 $(".single_add_to_cart_button").show();
                 
            });
        </script>
<script type="text/javascript">
    jQuery(document).ready(function(e){
    // Submit form data via Ajax
    jQuery("#formId").on('submit', function(e)
    {
        e.preventDefault();
        
        // get file field value using field id
        var fileInputElement = document.getElementById("file");
        if($('#file').val()==''){
            $('.uploaderror').html('Please choose a file');
            return;
        }
        $('.uploaderror').html('');
        var fileName = fileInputElement.files[0].name;
        
        
        
        
        if(1)
        {
            var ajax_url = '<?php echo admin_url('admin-ajax.php'); ?>';
            jQuery.ajax({
                url:ajax_url,
                type:"POST",
                processData: false,
                contentType: false,
                data:  new FormData(this),
                success : function( response ){
                    
                    $('#hidden-1648725802929').val(response);
                    $('.upload_form_outer').hide();
                    $('.addonproductcancelbutton').attr('backclass','upload_form_outer');
                    $('.wapf-wrapper').show();
                    
                },
            });
            return false;
        }
        return false;
    });
});
</script>